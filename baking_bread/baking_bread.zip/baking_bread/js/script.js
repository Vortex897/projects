function updateCount() {
    document.getElementById("money").innerHTML = "Money: $" + money.toFixed(2);
}

window.onload = () => {
    updateCount();
}

const weedBtn = document.getElementById("weed");
let weeding = false;

function weed() {
    if (!weeding){
        weedBtn.textContent = "Weeding...";
        weeding = true;
        setTimeout(() => {
            money += 1;
            weeding = false;
            weedBtn.textContent = "Weed";
            updateCount();
        }, 5000);
    } else {
        alert("You are already weeding!")
    }
}