function updateCount() {
    document.getElementById("money").innerHTML = "Money: $" + money.toFixed(2);
}

window.onload = () => {
    updateCount();
}