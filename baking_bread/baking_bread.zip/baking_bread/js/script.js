let money = 100.0;

function updateCount() {
    document.getElementById("money").innerHTML = "Money: $" + money.toFixed(2)
    console.log(money);
}

const weedBtn = document.getElementById("weed");
let weeding = false;

function weed() {
    if (!weeding){
        weeding = true;

        for (let i = 5; i >= 0; i--) {
            setTimeout(() => {
                if (i > 0) {
                    weedBtn.textContent = `Weeding... (${i}s)`;
                } else {
                    money += 1;
                    weeding = false;
                    weedBtn.textContent = "Weed";
                    updateCount();
                }
            }, (5 - i) * 1000);
            
        }
    } else {
        alert("You are already weeding!")
    }
}

setInterval(() => {
    saveGame();
    console.log("Auto save.")
}, 60000)

window.onload = () => {
    loadGame();

    Object.entries(structures).forEach(([id, structures]) => {
        if (structures.owned) {
            structures.showFn();
        }
    });
};