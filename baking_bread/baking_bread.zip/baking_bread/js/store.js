let cupPrice = 50.0;
let multiplier = 1;
let store = false;

let itensStore = {
    itensStoreGUI: false,
    water: 2.5,
    wheat_seed: 2.5
};

let sell = {
    sellGUI: false,
    water2: 1.5,
    wheat_seed2: 1.5,
    wheat2 : 7.5
};

const guiStates = {
    itensStore: {
        obj: itensStore,
        div: "itensStoreDiv",
        showFn: showItensStore,
        hideFn: hideItensStore
    },
    sell: {
        obj: sell,
        div: "sellDiv",
        showFn: showSell,
        hideFn: hideSell
    }
};

const multipliers = {
    x1: 1,
    x10: 10,
    x100: 100
};

Object.entries(multipliers).forEach(([id, value]) => {
    document.getElementById(id).onclick = () => multiplier = value;
});

["itensStore", "sell"].forEach(menu => {
    document.getElementById(menu).onclick = () => toggleMenu(menu);
});

function capitalize(str) {
    return str.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()).replace(/2/g, "");
};

function openStore() {
    store = !store;

    ["x1", "x10", "x100", "itensStore", "sell"].forEach(id => {
        document.getElementById(id).style.display = store ? "block" : "none";
    });

    if (!store) {
        Object.keys(guiStates).forEach(menu => {
            guiStates[menu].obj[menu + "GUI"] = false;
            guiStates[menu].hideFn();
        });
    }
}

function toggleMenu(menu) {
    let current = guiStates[menu];
    current.obj[menu + "GUI"] = !current.obj[menu + "GUI"];

    Object.keys(guiStates).forEach(m => {
        const { obj, div, hideFn } = guiStates[m];
        const el = document.getElementById(div);

        if (m === menu && obj[menu + "GUI"]) {
            guiStates[m].showFn();
            el.style.display = "block";
        } else {
            obj[m + "GUI"] = false;
            hideFn();
            el.style.display = "none";
        }
    });
}

function showItensStore() {
    renderButtons(itensStore, "itensStoreDiv", buyItens);
}
function showSell() {
    renderButtons(sell, "sellDiv", sellItens);
}
function hideItensStore() {
    document.getElementById("itensStoreDiv").innerHTML = "";
}
function hideSell() {
    document.getElementById("sellDiv").innerHTML = "";
}

function renderButtons(storeObj, containerId, action) {
    const container = document.getElementById(containerId);
    container.innerHTML = "";

    for (let i in storeObj) {
        if (i.endsWith("GUI")) continue;

        const btn = document.createElement("button");
        btn.textContent = `${capitalize(i)} $${storeObj[i].toFixed(2)}`;
        btn.id = i;
        btn.onclick = () => action(i);
        container.appendChild(btn);
    }
}
