let lotPrice = 50.0;

let store = false;

let itensStore = {
    itensStoreGUI: false,
    water: 2.5,
    wheat_seed: 2.5
}

let toolsStore = {
    toolsStoreGUI: false,
    lot: lotPrice
}

let sell = {
    sellGUI: false,
    wheat2 : 7.5
}

let multiplier = 1;

const x1 = document.getElementById("x1");
const x10 = document.getElementById("x10");
const x100 = document.getElementById("x100");
const xall = document.getElementById("xall");

const itensStoreBtn = document.getElementById("itensStore");
const toolsStoreBtn = document.getElementById("toolsStore");
const sellBtn = document.getElementById("sell");

const itensStoreDiv = document.getElementById("itensStoreDiv");
const toolsStoreDiv = document.getElementById("toolsStoreDiv");
const sellDiv = document.getElementById("sellDiv");

function capitalize(str) {
    return str.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()).replace(/2/g, "");
}

//main store functions

function openStore() {
    store = !store;

    if (store) {
        x1.style.display = "block";
        x10.style.display = "block";
        x100.style.display = "block";

        itensStoreBtn.style.display = "block";
        toolsStoreBtn.style.display = "block";
        sellBtn.style.display = "block";
    } else {
        hideItensStore();
        itensStore.itensStoreGUI = false;

        hideToolsStore();
        toolsStore.toolsStoreGUI = false;

        hideSell();
        sell.sellGUI = false;

        x1.style.display = "none";
        x10.style.display = "none";
        x100.style.display = "none";

        itensStoreBtn.style.display = "none";
        toolsStoreBtn.style.display = "none";
        sellBtn.style.display = "none";
    }
}

//open store components functions

function openItensStore() {
    itensStore.itensStoreGUI = !itensStore.itensStoreGUI;

    if (itensStore.itensStoreGUI) {
        showItensStore();
        hideToolsStore();
        hideSell();

        itensStoreDiv.style.display = "block";
        toolsStoreDiv.style.display = "none";
        sellDiv.style.display = "none";

        toolsStore.toolsStoreGUI = false;
        sell.sellGUI = false;

    } else {
        hideItensStore();
        itensStoreDiv.style.display = "none";
    }
}

function openToolsStore() {
    toolsStore.toolsStoreGUI = !toolsStore.toolsStoreGUI;

    if (toolsStore.toolsStoreGUI) {
        hideItensStore();
        showToolsStore();
        hideSell();

        itensStoreDiv.style.display = "none";
        toolsStoreDiv.style.display = "block";
        sellDiv.style.display = "none";

        itensStore.itensStoreGUI = false;
        sell.sellGUI = false;
        
    } else {
        hideToolsStore();
        toolsStoreDiv.style.display = "none";
    }
}

function openSell() {
    sell.sellGUI = !sell.sellGUI;

    if(sell.sellGUI) {
        hideItensStore();
        hideToolsStore();
        showSell();

        itensStoreDiv.style.display = "none";
        toolsStoreDiv.style.display = "none";
        sellDiv.style.display = "block";

        toolsStore.toolsStoreGUI = false;
        itensStore.itensStoreGUI = false;
        
    } else {
        hideSell();
        sellDiv.style.display = "none";
    }
}

//show functions

function showItensStore() {
    itensStoreDiv.innerHTML = "";

    for (let i in itensStore) {
        if (i === "itensStoreGUI") continue;
        const btn = document.createElement("button");

        btn.textContent = `${capitalize(i)} $${itensStore[i].toFixed(2)}`;
        btn.id = `${i}`;
        btn.onclick = () => {
            buyItens(i);
        }

        itensStoreDiv.appendChild(btn);
    }
}

function showToolsStore() {
    toolsStoreDiv.innerHTML = "";

    for (let i in toolsStore) {
        if (i === "toolsStoreGUI") continue;
        const btn = document.createElement("button");

        btn.textContent = `${capitalize(i)} $${toolsStore[i].toFixed(2)}`;
        btn.id = `${i}`;
        btn.onclick = () => {
            buyTools(i);
        }

        toolsStoreDiv.appendChild(btn);
    }
}

function showSell() {
    sellDiv.innerHTML = "";

    for (let i in sell) {
        if (i === "sellGUI") continue;

        const btn = document.createElement("button");
        btn.textContent = `${capitalize(i)} $${sell[i].toFixed(2)}`;
        btn.id = `${i}`;
        btn.onclick = () => {
            sellItens(i);
        }

        sellDiv.appendChild(btn);
    }
}

//hide functions

function hideItensStore() {
    itensStoreDiv.innerHTML = "";
}

function hideToolsStore() {
    toolsStoreDiv.innerHTML = "";
}

function hideSell() {
    sellDiv.innerHTML = "";
}

//multiplier buttons functions

function multiplier1x() {
    multiplier = 1;
}

function multiplier10x() {
    multiplier = 10;
}

function multiplier100x() {
    multiplier = 100;
}
