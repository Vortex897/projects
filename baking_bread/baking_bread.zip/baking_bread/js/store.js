let potPrice = 50.0;

let store = false;

let itensStore = {
    itensStoreGUI: false,
    water: 5.0,
    wheat_seed: 5.0
}

let toolsStore = {
    toolsStoreGUI: false,
    pot: potPrice
}

let sell = {
    sellGUI: false,
    water2: 3.75,
    wheat_seed2: 3.75
}

const itensStoreBtn = document.getElementById("itensStore");
const toolsStoreBtn = document.getElementById("toolsStore");
const sellBtn = document.getElementById("sell");

const itensStoreDiv = document.getElementById("itensStoreDiv");
const toolsStoreDiv = document.getElementById("toolsStoreDiv");
const sellDiv = document.getElementById("sellDiv");

function capitalize(str) {
    return str.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()).replace(/2/g, "");
}

//main store functions

function openStore() {
    store = !store;

    if (store) {
        itensStoreBtn.style.display = "block";
        toolsStoreBtn.style.display = "block";
        sellBtn.style.display = "block";
    } else {
        hideItensStore();
        itensStore.itensStoreGUI = false;

        hideToolsStore();
        toolsStore.toolsStoreGUI = false;

        hideSell();
        sell.sellGUI = false;

        itensStoreBtn.style.display = "none";
        toolsStoreBtn.style.display = "none";
        sellBtn.style.display = "none";
    }
}

//open store components functions

function openItensStore() {
    itensStore.itensStoreGUI = !itensStore.itensStoreGUI;

    if (itensStore.itensStoreGUI) {
        showItensStore();
        hideToolsStore();
        hideSell();

        itensStoreDiv.style.display = "block";
        toolsStoreDiv.style.display = "none";
        sellDiv.style.display = "none";

        toolsStore.toolsStoreGUI = false;
        sell.sellGUI = false;

    } else {
        hideItensStore();
        itensStoreDiv.style.display = "none";
    }
}

function openToolsStore() {
    toolsStore.toolsStoreGUI = !toolsStore.toolsStoreGUI;

    if (toolsStore.toolsStoreGUI) {
        hideItensStore();
        showToolsStore();
        hideSell();

        itensStoreDiv.style.display = "none";
        toolsStoreDiv.style.display = "block";
        sellDiv.style.display = "none";

        itensStore.itensStoreGUI = false;
        sell.sellGUI = false;
        
    } else {
        hideToolsStore();
        toolsStoreDiv.style.display = "none";
    }
}

function openSell() {
    sell.sellGUI = !sell.sellGUI;

    if(sell.sellGUI) {
        hideItensStore();
        hideToolsStore();
        showSell();

        itensStoreDiv.style.display = "none";
        toolsStoreDiv.style.display = "none";
        sellDiv.style.display = "block";

        toolsStore.toolsStoreGUI = false;
        itensStore.itensStoreGUI = false;
        
    } else {
        hideSell();
        sellDiv.style.display = "none";
    }
}

//show functions

function showItensStore() {
    itensStoreDiv.innerHTML = "";

    for (let i in itensStore) {
        if (i === "itensStoreGUI") continue;
        const btn = document.createElement("button");

        btn.textContent = `${capitalize(i)} $${itensStore[i].toFixed(2)}`;
        btn.id = `${i}`;

        itensStoreDiv.appendChild(btn);
    }
}

function showToolsStore() {
    toolsStoreDiv.innerHTML = "";

    for (let i in toolsStore) {
        if (i === "toolsStoreGUI") continue;
        const btn = document.createElement("button");

        btn.textContent = `${capitalize(i)} $${toolsStore[i].toFixed(2)}`;
        btn.id = `${i}`;
        btn.onclick = () => {
            buyTools(i);
        }

        toolsStoreDiv.appendChild(btn);
    }
}

function showSell() {
    sellDiv.innerHTML = "";

    for (let i in sell) {
        if (i === "sellGUI") continue;

        const btn = document.createElement("button");
        btn.textContent = `${capitalize(i)} $${sell[i].toFixed(2)}`;
        btn.id = `${i}`;


        sellDiv.appendChild(btn);
    }
}

//hide functions

function hideItensStore() {
    itensStoreDiv.innerHTML = "";
}

function hideToolsStore() {
    toolsStoreDiv.innerHTML = "";
}

function hideSell() {
    sellDiv.innerHTML = "";
}