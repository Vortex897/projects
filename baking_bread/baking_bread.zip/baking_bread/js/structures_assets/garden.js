const lot = document.getElementById("lot");
let lotLevel = structures.garden.level;
let lotName = ["cup", "old boot", "pot", "large pot", "small lot", "lot", "big lot"];
let lotSlots = 1;

let upGardenPrice = 50.0;

function plant() {
    if (lot.dataset.planted === "empty") {
        if (inventory.water >= lotSlots && inventory.wheat_seeds >= lotSlots) {
            lot.dataset.planted = "planted";
            inventory.water -= lotSlots;
            inventory.wheat_seeds -= lotSlots;
            updateInventory();

            for (let i = 5; i >= 0; i--) {
                setTimeout(() => {
                    if (i > 0) {
                        lot.innerHTML = `Growing... (${i}s)` 
                    } else {
                        lot.dataset.planted = "mature";
                        lot.innerHTML = "Mature";
                    }
                }, (5 - i) * 1000);
            }
        } else if (inventory.wheat_seeds >= lotSlots) {
            alert("You don't have enough water!");
        } else if (inventory.water >= lotSlots) {
            alert("You don't have enough seeds!");
        } else {
            alert("You don't have enough water any seeds!");
        }
        
    } else if (lot.dataset.planted === "mature") {
        lot.dataset.planted = "empty";
        lot.innerHTML = `Empty ${lotName[lotLevel]} (${lotSlots} slots)`;
        inventory.wheat += lotSlots;
        updateInventory();
    } else {
        alert(`This ${lotName[lotLevel]} has already been planted!`);
    }
}

function upgradeGarden() {
    if (money >= upGardenPrice) {
        lotLevel += 1;
        lotSlots *= 2;
        money -= upGardenPrice;
        upGardenPrice += upGardenPrice * 1.5;
        updateCount();

        document.getElementById("upgradeLot").innerHTML = `Upgrade ${lotName[lotLevel]} $${upGardenPrice.toFixed(2)}`;
        lot.innerHTML = `Empty ${lotName[lotLevel]} (${lotSlots} slots)`;
    } else {
        alert("You don't have enough money to buy this!");
    }
}