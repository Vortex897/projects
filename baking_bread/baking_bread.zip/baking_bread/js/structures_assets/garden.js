const lot = document.getElementById("lot");

function plant() {
    if (lot.dataset.planted === "empty") {
        
    }
}