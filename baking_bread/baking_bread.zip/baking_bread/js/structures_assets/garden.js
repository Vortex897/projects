const potsDiv = document.getElementById("pots");
potIdNum = 0;

function newPot() {
    potIdNum++;
    const btn = document.createElement("button");
    btn.textContent = "Empty pot";
    btn.id = `pot${potIdNum}`;
    btn.dataset.condition = "empty";
    btn.onclick = () => {
        plant(btn);
    }

    potsDiv.appendChild(btn);
}

function plant(button) {
    if (button.dataset.condition === "planted") {
        alert("This pot is already planted!");
        return;
    } else if (button.dataset.condition === "mature") {
        button.dataset.condition = "empty";
        button.textContent = "Empty Pot";
        inventory.wheat += 1;
        updateInventory();
        return;
    }
        
    if (inventory.wheat_seeds >= 1 && inventory.water >= 1) {
        inventory.wheat_seeds -= 1;
        inventory.water -= 1;
        updateInventory();

        button.dataset.condition = "planted";
        button.textContent = "Growing...";

        setTimeout(() => {
            button.dataset.condition = "mature"
            button.textContent = "Mature Plant"
        }, 10000);

    } else if (inventory.wheat_seeds >= 1) {
        alert("You don't have enough water!");
    } else {
        alert("You don't have enough seeds!");
    }
}