const potsDiv = document.getElementById("pots");
potIdNum = 0;

function newPot() {
    potIdNum++;
    const btn = document.createElement("button");
    btn.textContent = "Pot";
    btn.id = `pot${potIdNum}`;
    btn.onclick = () => {
        plant();
    }

    potsDiv.appendChild(btn);
}

function plant() {
    let seeded = false;
    
    if (!seeded) {
        setInterval(() => {
            
        }, 10000)
    }
}