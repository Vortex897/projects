const lotsDiv = document.getElementById("lots");
lotIdNum = 0;

function newLot() {
    lotIdNum++;
    const btn = document.createElement("button");
    btn.textContent = "Empty lot";
    btn.id = `lot${lotIdNum}`;
    btn.dataset.condition = "empty";
    btn.onclick = () => {
        plant(btn);
    }

    lotsDiv.appendChild(btn);
}

function plant(button) {
    if (button.dataset.condition === "planted") {
        alert("This lot is already planted!");
        return;
    } else if (button.dataset.condition === "mature") {
        button.dataset.condition = "empty";
        button.textContent = "Empty Lot";
        inventory.wheat += 1;
        updateInventory();
        return;
    }
        
    if (inventory.wheat_seeds >= 1 && inventory.water >= 1) {
        inventory.wheat_seeds -= 1;
        inventory.water -= 1;
        updateInventory();

        button.dataset.condition = "planted";
        button.textContent = "Growing...";

        setTimeout(() => {
            button.dataset.condition = "mature"
            button.textContent = "Mature Plant"
        }, 5000);

    } else if (inventory.wheat_seeds < 1 && inventory.water < 1) {
        alert("You don't have enough water and seeds!");
    } else if (inventory.wheat_seeds < 1) {
        alert("You don't have enough seeds!");
    } else {
        alert("You don't have enough water!");
    }
}
