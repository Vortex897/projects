let structures = {
    garden: false,
}

const storeBtn = document.getElementById("store"); 
const buyMortarBtn = document.getElementById("buyMortarBtn");
const gardenBox = document.getElementById("gardenBoxId");

function buyGarden() {
    if (money >= 100) {
        money -= 100;
        structures.garden = true;
        updateCount();
        hideBuyGardenBtn();
        showGarden();
        newCup();

        buyMortarBtn.style.display = "block";
    } else {
        alert("You don't have enough money to buy this!");
    }
}

function hideBuyGardenBtn() {
    const buyGardenBtn = document.getElementById("buyGardenBtn");
    buyGardenBtn.style.display = "none";
    updateCount();
}

function showGarden() {
    gardenBox.style.display = "block";
        storeBtn.style.display = "block";
}