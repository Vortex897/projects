let structures = {
    garden: {
        owned: false,
        level: 0,
        price: 100,
        buttonId: "buyGardenBtn",
        elementId: "gardenBoxId",
        nextBtnId: "buyMortarBtn",
        showFn: () => {
            document.getElementById("gardenBoxId").style.display = "block";
            document.getElementById("store").style.display = "block";
            document.getElementById("lot").innerHTML = `Empty ${lotName[lotLevel]} (${lotSlots} slots)`;
        }
    },
    // mortar: {
    //     owned: false,
    //     level: 0,
    //     showFn: showMortar
    // }
}

function buyStructure(id) {
    const structure = structures[id];

    if (structure.owned) return;

    if (money >= structure.price) {
        money -= structure.price;
        structure.owned = true;
        updateCount();

        document.getElementById(structure.buttonId).style.display = "block";

        structure.showFn();

        showNextBtn(structure.nextBtnId);
    } else {
        alert("You don't have enough money to buy this structure!");
    }
}

function showNextBtn(nextBtnId) {
    if (nextBtnId){
            const nextBtn = document.getElementById(nextBtnId);
            if (nextBtn) nextBtn.style.display = "block"; 
    }
}