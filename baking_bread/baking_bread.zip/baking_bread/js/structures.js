let structures = {
    garden: {
        value: false,
        showFn: showGarden
    },
    // mortar: {
    //     value: false,
    // }
}


const storeBtn = document.getElementById("store"); 
const buyMortarBtn = document.getElementById("buyMortarBtn");
const gardenBox = document.getElementById("gardenBoxId");

function buyGarden() {
    if (money >= 100) {
        money -= 100;
        structures.garden = true;
        updateCount();
        hideBuyGardenBtn();
        showGarden();

        buyMortarBtn.style.display = "block";
    } else {
        alert("You don't have enough money to buy this!");
    }
}

function hideBuyGardenBtn() {
    const buyGardenBtn = document.getElementById("buyGardenBtn");
    buyGardenBtn.style.display = "none";
    updateCount();
}

function showGarden() {
    gardenBox.style.display = "block";
    storeBtn.style.display = "block";
    document.getElementById("lot").innerHTML = `Empty ${lotName[lotLevel]} (${lotSlots} slots)`
}

window.onload = () => {
    loadGame();

    Object.entries(structures).forEach(([id, structures]) => {
        if (structures.value) {
            structures.showFn();
        }
    });
};