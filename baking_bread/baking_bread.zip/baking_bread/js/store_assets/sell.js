function sellItens(itemId) {
    switch (itemId) {
        case "water2":
            if (inventory.water >= 1 * multiplier) {
                inventory.water -= 1 * multiplier;
                money += 1.5 * multiplier;
                updateInventory();
                updateCount();
            } else {
                alert("You don't have water to seel!");
            }
            break;

        case "wheat_seed2":
            if (inventory.wheat_seeds >= 1 * multiplier) {
                inventory.wheat_seeds -= 1 * multiplier;
                money += 1.5 * multiplier;
                updateInventory();
                updateCount();
            } else {
                alert("You don't have wheat seeds to sell!");
            } 
            break;

        case "wheat2":
            if (inventory.wheat >= 1 * multiplier) {
                inventory.wheat -= 1 * multiplier;
                money += 7.5 * multiplier;
                updateInventory();
                updateCount();
            } else {
                alert("You don't have wheat to sell!");
            }
            break;
    }
}