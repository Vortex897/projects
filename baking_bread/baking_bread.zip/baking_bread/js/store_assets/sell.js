function sellItens(itemId) {
    switch (itemId) {
        case "wheat2":
            if (inventory.wheat >= 1 * multiplier) {
                inventory.wheat -= 1 * multiplier;
                money += 10 * multiplier;
                updateInventory();
                updateCount();
            } else {
                alert("You don't have wheat to sell!")
            }
            break;
    }
}