function sellItens(itemId) {
    switch (itemId) {
        case "wheat2":
            if (inventory.wheat >= 1) {
                inventory.wheat -= 1;
                money += 10;
                updateInventory();
                updateCount();
            } else {
                alert("You don't have wheat to sell!")
            }
            break;
    }
}