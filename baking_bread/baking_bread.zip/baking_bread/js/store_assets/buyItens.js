function buyItens(itemId) {
    switch(itemId) {
        case 'water':
            if (money >= itensStore.water * multiplier) {
                money -= itensStore.water * multiplier;
                inventory.water += 1 * multiplier;

                updateCount();
                updateInventory();
            } else {
                alert("You don't have enough money!");
            }
            break;
        
        case 'wheat_seed':
            if (money >= itensStore.wheat_seed * multiplier) {
                money -= itensStore.wheat_seed * multiplier;
                inventory.wheat_seeds += 1 * multiplier;

                updateCount();
                updateInventory();
            } else {
                alert("You don't have enough money!");
            }
            break;
    }
}