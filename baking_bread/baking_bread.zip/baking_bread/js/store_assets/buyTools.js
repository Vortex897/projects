let i = 0;

function buyTools(itemId) {
    switch (itemId) {
        case "lot":
            i = 0;
            if (money >= lotPrice && structures.garden) {
                while (money >= lotPrice && i < multiplier) {
                    buyLot();
                    i++;
                }
            } else if (!structures.garden) {
                alert("You have to buy the garden!");
            } else {
                alert("You don't have enough money!");
            }
            break;
    } // <-- fechamento correto do switch
}

function buyLot() {
    money -= lotPrice;
    if (lotIdNum >= 1) {
        lotPrice += lotPrice * 2;
    }

    toolsStore.lot = lotPrice;

    updateCount();
    newLot();
    showToolsStore();
}
