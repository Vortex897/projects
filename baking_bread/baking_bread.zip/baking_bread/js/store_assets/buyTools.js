function buyTools(itemId) {
    switch (itemId) {
        case "pot":
            if (money >= potPrice && structures.garden) {
                money -= potPrice;
                potPrice += potPrice * 2;

                toolsStore.pot = potPrice;

                updateCount();
                newPot();
                showToolsStore();
            } else if (!structures.garden){
                alert("You have to buy the garden!");
            } else {
                alert("You don't have enough money!")
            }
            break;
    }
}