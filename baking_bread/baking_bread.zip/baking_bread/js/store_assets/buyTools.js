function buyTools(itemId) {
    switch (itemId) {
        case "pot":
            if (money >= potPrice) {
                money -= potPrice;
                potPrice += potPrice * 0.75;

                toolsStore.pot = potPrice;

                updateCount();
                newPot();
                showToolsStore();
            }
            break;
    }
}