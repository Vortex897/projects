// main functions

function saveGameBtn() {
    console.log("Game saved.");
    saveGame();
}

function saveGame() {
    saveInventory();
    saveStructures();
}

function loadGame() {
    loadStructures();
    loadInventory();

    updateCount();
}

function deleteSave() {
    const answer = confirm("Are you sure you want to delete your progress? This is irreversible!")
    if (answer) {
        localStorage.clear();
        alert("Progress deleted!");
        location.reload();
    } else {
        alert("Cancelled");
    }
}

//save functions

function saveStructures() {
    const saveData = {};

    for (const key in structures) {
        saveData[key] = {
            owned: structures[key].owned,
            level: structures[key].level
        };
    }

    
    localStorage.setItem("structures", JSON.stringify(saveData));
}

function saveInventory() {
    localStorage.setItem("money", money);
    localStorage.setItem("inventory", JSON.stringify(inventory));
}

//load functions

function loadStructures() {
    const savedStructures = JSON.parse(localStorage.getItem("structures"));
    if (savedStructures) {
        for (const key in savedStructures) {
            if(structures[key]) {
                structures[key].owned = savedStructures[key].owned;
                structures[key].level = savedStructures[key].level;
                if (structures[key].owned) {
                    structures[key].showFn();
                }
            }
        }
    }
}

function loadInventory() {
    const savedMoney = localStorage.getItem("money");
    money = savedMoney !== null ? parseFloat(savedMoney) : 1000.0;

    const savedInventory = localStorage.getItem("inventory");
    if (savedInventory) {
        const parsed = JSON.parse(savedInventory);
        for (let key in parsed) {
            if (key === "inventoryGUI") continue;
            inventory[key] = parsed[key];
        }
    }
}