function saveGame() {
    localStorage.setItem("garden", structures.garden.value)
}

function loadGame() {
    Object.keys(structures).forEach(key => {
        structures[key].value = localStorage.getItem(key) === "true";   
    });
}