const structureStoreDiv = document.getElementById("structureStoreDiv");
const structureDiv = document.getElementById("structureDiv");


let structures = {
    oven: {
        price: 15,
        minimum: 15,
        count: 0,
        bps: 0.1,
        buttonId: "buyOvenBtn",
    },
    bakery: {
        price: 100,
        minimum: 100,
        count: 0,
        bps: 1,
        buttonId: "buyBakeryBtn",
    },
    wheat_farm: {
        price: 1000,
        minimum: 1000,
        count: 0,
        bps: 10,
        buttonId: "buyWheatFarmBtn",
    },
    salt_mine: {
        price: 10000,
        minimum: 10000,
        count: 0,
        bps: 100,
        buttonId: "buySaltMineBtn",
    },
    yeast_factory: {
        price: 100000,
        minimum: 100000,
        count: 0,
        bps: 1000,
        buttonId: "buyYeastFactoryBtn",
    }
}

let structureCount = 0;

function capitalize(str) {
    return str.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

function showBuyStructureBtn() {
    structureStoreDiv.innerHTML = "";

    for (let i in structures) {
        if (totalCount < structures[i].minimum) continue;

        const btn = document.createElement("button");
        btn.textContent = `Buy ${capitalize(i)} (+${structures[i].bps} bps): ${structures[i].price.toFixed(0)} breads`;
        btn.style.display = "block";
        btn.className = "storeBtn";
        btn.onmouseover = "showStructureInfo(event, 'Informações do item')";
        btn.onmouseout = "hideStructureInfo()";
        btn.onclick = () => {
            if(count >= structures[i].price){
                count -= structures[i].price;
                structures[i].count += 1;
                structures[i].price = Math.round(structures[i].price * 1.15);
                if (multiplier > 0) {
                    autoCount += structures[i].bps * multiplier;
                } else {
                    autoCount += structures[i].bps;
                }
                structureCount += 1;
                if (structureCount > 0) document.getElementById("structuresDisplay").style.display = "block";
                
                updateCount();
                displayStructures();

                if (structures.oven.count != 0) structureDiv.style.display = "block";
                btn.textContent = `Buy ${capitalize(i)} (+${structures[i].bps} bps): ${structures[i].price.toFixed(0)} breads`;
            } else {
                alert("You don't have enough breads!")
            }
        };

        structureStoreDiv.appendChild(btn);
    }
}

function saveStructures() {
    for (let i in structures) {
        localStorage.setItem(`${i}_price`, structures[i].price);
        localStorage.setItem(`${i}_count`, structures[i].count);
    }
    localStorage.setItem("structuresCount", structureCount);
}

function loadStructures() {
    for (let i in structures) {
        structures[i].price = parseFloat(localStorage.getItem(`${i}_price`)) || structures[i].price;
        structures[i].count = parseInt(localStorage.getItem(`${i}_count`)) || 0;
    }
    structureCount = parseInt(localStorage.getItem("structuresCount")) || 0;
}

function displayStructures() {
    structureDiv.innerHTML = "";
    for (let i in structures) {
        if (structures[i].count == 0) continue;
        const p = document.createElement("p");
        if (multiplier > 0) {
            p.textContent = `${capitalize(i)}: ${structures[i].count} (+${(structures[i].count * structures[i].bps * multiplier).toFixed(1)} bps)`;
        } else {
        p.textContent = `${capitalize(i)}: ${structures[i].count} (+${(structures[i].count * structures[i].bps).toFixed(1)} bps)`;            
        }
        structureDiv.appendChild(p);
    }
}

function showStructureInfo(event, text) {
    const structureInfo = document.getElementById("structureInfo");
    structureInfo.innerText = text;
    structureInfo.style.display = "block";
    structureInfo.style.left = (event.pageX + 10) + "px";
    structureInfo.style.top = (event.pageY + 10) + "px";
}

function hideStructureInfo() {
    document.getElementById("structureInfo").style.display = "none";
}