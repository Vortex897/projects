let improvementsStore = {
    salt: {
        price: 15,
        minimum: 0
    }
}

const improvementsDiv = document.getElementById("improvementsDiv");
const buyImprovementsDiv = document.getElementById("buyImprovementsDiv");

function updateImprovements() {
    improvementsDiv.innerHTML = "";

    for (let i in improvementsGUI) {
        if (improvementsGUI[i] == 0) continue;
        const p = document.createElement("p");

        p.textContent = `${capitalize(i)}: ${improvementsGUI[i]}`;

        improvementsDiv.appendChild(p);
    }
}
