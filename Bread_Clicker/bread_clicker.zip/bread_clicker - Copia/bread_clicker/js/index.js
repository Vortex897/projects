let count = 0
let countValue = 1;
let autoCount = 0;

setInterval(() => {
    count += autoCount;
    updateCount();
}, 1000)

setInterval(saveGame, 5000);


function click1() {
    push();
    count += countValue;
    updateCount();

    if (count == 100){
        showSurpriseImage();
    } else {
        hideSurpriseImage();
    }
}

function updateCount(){
    document.getElementById("count").innerHTML = "Breads: " + Math.floor(count);
}

function showSurpriseImage() {
    const img = document.getElementById("surpriseImage");
    img.src = "../images/baking_bread.jpg";
    img.alt = "Surprise Image";
}

function hideSurpriseImage() {
    const img = document.getElementById("surpriseImage");
    img.src = "";
    img.alt = "";
}

function saveGame() {
    localStorage.setItem("breads", count);
    localStorage.setItem("countValue", countValue);
    localStorage.setItem("autoCount", autoCount);
    localStorage.setItem("salt", saltcount);
    localStorage.setItem("oven", oven);
    localStorage.setItem("ovenPrice", ovenPrice);
}

function loadGame() {
    count = parseInt(localStorage.getItem("breads")) || 0;
    countValue = parseInt(localStorage.getItem("countValue")) || 1;
    autoCount = parseInt(localStorage.getItem("autoCount")) || 0;
    salt = parseInt(localStorage.getItem("salt")) || 0;
    oven = parseInt(localStorage.getItem("oven")) || 0;
    ovenPrice = parseFloat(localStorage.getItem("ovenPrice")) || 15;
    updateCount();
    updateOvenButton();
}

window.onload = loadGame;