let oven = 0;
let ovenPrice = 15;

ovenPrice = Math.round(ovenPrice);

document.getElementById("buyOvenBtn").value = `Buy a oven (${ovenPrice} breads)`

function updateOvenButton() {
    ovenPrice = Math.round(ovenPrice);
    document.getElementById("buyOvenBtn").value = `Buy a oven (${ovenPrice} breads)`;
}

updateOvenButton();

function buyOven() {
    if(count >= ovenPrice){
        count -= ovenPrice;
        oven += 1;
        autoCount += 1; 
        ovenPrice += (ovenPrice * 0.25) 
        updateOvenButton();
        updateCount();
    }
}