function push() {
    const bread = document.getElementById("bread");

    bread.classList.remove("pushing");

    void bread.offsetWidth;
    
    bread.classList.add("pushing")
}