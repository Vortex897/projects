let ascensionPrice = 1000;
let ascensionCount = 0;

const ascensionCD = document.getElementById("ascensionDisplay"); //ascensionCountDisplay :0

function resetProgress() {
    count = 0;
    totalCount = 0;
    countValue = 1;
    autoCount = 0;

    for (let i in structures) {
        structures[i].price = 15;
        structures[i].count = 0;
    }

    updateCount();
    updatePerSecond();
}

function ascension() {
    if (totalCount >= ascensionPrice) {
        if (confirm("Are you sure you want to anscenion? (Your progress will be reset!)")) {
            resetProgress();     
                   
            multiplier += 0.01;
            ascensionPrice += ascensionPrice * 0.01;
            ascensionCount += 1;

            saveGame();
            window.location.reload();
            ascensionDisplay();
    } 
    } else {
        alert("You don't have enough total breads!");
    }
}

function ascensionDisplay() {
    if (ascensionCount > 0) {
        ascensionCD.textContent = `Ascencion points: ${ascensionCount} (+${ascensionCount * 1}% bps)`;
    }
}

function saveAscension() {
    localStorage.setItem("ascensionPrice", ascensionPrice);
    localStorage.setItem("ascensionCount", ascensionCount);
}

function loadAscension() {
    ascensionPrice = parseInt(localStorage.getItem("ascensionPrice")) || 1000;
    ascensionCount = parseInt(localStorage.getItem("ascensionCount")) || 0;
}