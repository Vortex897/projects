function ascension() {
    if (confirm("Are you sure you want to anscenion? (Your progress will be reset!)")) {
        localStorage.clear();
        window.location.reload();
        multiplier += 0.10;
        ascensionPrice += ascensionPrice * 0.1;
    }
}