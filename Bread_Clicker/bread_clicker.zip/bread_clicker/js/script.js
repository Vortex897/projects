let count = 0;
let multiplier = 0;
let countValue = 1 + (1 * multiplier);
let autoCount = 0;
let totalCount = 0;
let ascensionPrice = 1000;

const ascensionBtn = document.getElementById("ascensionBtn");

setInterval(() => {
    count += autoCount;
    totalCount += autoCount;

    updatePerSecond()
    updateCount();
    showBuyStructureBtn();
}, 1000)

setInterval(() => {
    saveGame();
}, 60000);

function click1() {
    push();
    count += countValue;
    totalCount += countValue;
    updateCount();
    showBuyStructureBtn;

    if (totalCount >= 1000){
        showSurpriseImage();
    } else {
        hideSurpriseImage();
    }
}

function updatePerSecond() {
    document.getElementById("bps").innerHTML = "Per second: " + Math.floor(autoCount) + "bps";
}

function updateCount(){
    document.getElementById("count").innerHTML = "Breads: " + Math.floor(count);
}

function showSurpriseImage() {
    const img = document.getElementById("surpriseImage");
    img.src = "../images/baking_bread.jpg";
    img.alt = "Surprise Image";
}

function hideSurpriseImage() {
    const img = document.getElementById("surpriseImage");
    img.src = "";
    img.alt = "";
}

function saveGame() {
    localStorage.setItem("breads", count);
    localStorage.setItem("totalBreads", totalCount);
    localStorage.setItem("countValue", countValue);
    localStorage.setItem("autoCount", autoCount);
    localStorage.setItem("multiplier", multiplier);
    localStorage.setItem("ascensionPrice", ascensionPrice);

    saveStructures();

    console.log("Game-saved");
}

function loadGame() {
    count = parseInt(localStorage.getItem("breads")) || 0;
    countValue = parseInt(localStorage.getItem("countValue")) || 1;
    autoCount = parseInt(localStorage.getItem("autoCount")) || 0;
    multiplier = parseInt(localStorage.getItem("multiplier")) || 0;
    ascensionPrice = parseInt(localStorage.getItem("ascensionPrice")) || 1000;
    updateCount();
    loadStructures();
}

function deleteSave() {
    if (confirm('Are you sure you want to delete this save?')) {
        localStorage.clear();
        window.location.reload();
    }
}

window.onload = () => {
    loadGame();
    showBuyStructureBtn();
    if (structures.oven.count != 0) {
        structureDiv.style.display = "block";
        displayStructures();
    } else {
        structureDiv.style.display = "none";
    }
    ascensionBtn.innerHTML = `Ascension (${ascensionPrice} breads)`;
}