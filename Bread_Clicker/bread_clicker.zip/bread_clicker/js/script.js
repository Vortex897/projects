let count = 0;
let multiplier = 0;
let countValue = 1;
let autoCount = 0;
let totalCount = 1000;

const ascensionBtn = document.getElementById("ascensionBtn");
const totalCountCD = document.getElementById("totalCountDisplay");

setInterval(() => {
    count += autoCount;
    totalCount += autoCount;
    totalCountCD.textContent = `Total breads in this ascension: ${totalCount.toFixed(0)} breads.`
    
    updatePerSecond();
    updateCount();
    showBuyStructureBtn();
}, 1000)

setInterval(() => {
    saveGame();
}, 60000);

function click1() {
    push();
    count += countValue;
    totalCount += countValue;
    totalCountCD.textContent = `Total breads in this ascension: ${totalCount.toFixed(0)} breads.`

    updateCount();
    showBuyStructureBtn();

    if (totalCount >= 1000){
        showSurpriseImage();
    } else {
        hideSurpriseImage();
    }

    turnBlock();
    
}

function updatePerSecond() {
    document.getElementById("bps").innerHTML = "Per second: " + autoCount.toFixed(1) + "bps";
}

function updateCount(){
    document.getElementById("count").innerHTML = count.toFixed(0) + " breads";
}

function showSurpriseImage() {
    const img = document.getElementById("surpriseImage");
    img.src = "../images/baking_bread.jpg";
    img.alt = "Surprise Image";
}

function hideSurpriseImage() {
    const img = document.getElementById("surpriseImage");
    img.src = "";
    img.alt = "";
}

function saveGame() {
    localStorage.setItem("breads", count);
    localStorage.setItem("totalBreads", totalCount);
    localStorage.setItem("countValue", countValue);
    localStorage.setItem("autoCount", autoCount);
    localStorage.setItem("multiplier", multiplier);

    saveStructures();
    saveAscension();

    console.log("Game-saved");
}

function loadGame() {
    count = parseFloat(localStorage.getItem("breads")) || 0;
    totalCount = parseFloat(localStorage.getItem("totalBreads")) || 0;
    countValue = parseFloat(localStorage.getItem("countValue")) || (1 + (1 * multiplier));
    autoCount = parseFloat(localStorage.getItem("autoCount")) || (0 + (1 * multiplier));
    multiplier = parseFloat(localStorage.getItem("multiplier")) || 0;

    updateCount();
    loadStructures();
    loadAscension();
}

function deleteSave() {
    if (confirm('Are you really want to delete your save?')) {
        if (confirm("Are you REALLY sure you want to delete your save?")) {
            localStorage.clear();
            window.location.reload();
        }
    }
}

function updateCountValue() {
    countValue = countValue + (1 * multiplier);
    autoCount = autoCount + (1 * multiplier);
}

function turnBlock() {
    if (totalCount >= 15) {
        document.getElementById("structures").style.display = "block";
        document.getElementById("structureStoreDiv").style.display = "block";
    }
    if (structureCount > 0) document.getElementById("structuresDisplay").style.display = "block";    
}

window.onload = () => {
    loadGame();
    showBuyStructureBtn();
    displayStructures();
    ascensionDisplay();
    updateCountValue();
    turnBlock();

    totalCountCD.textContent = `Total breads in this ascension: ${totalCount.toFixed(0)} breads.`
    ascensionBtn.textContent = `Ascension (${ascensionPrice} total breads)`;
}