const structureStoreDiv = document.getElementById("structureStoreDiv");
const structureDiv = document.getElementById("structureDiv");


let structures = {
    oven: {
        price: 15,
        minimum: 0,
        count: 0,
        bps: 1,
        buttonId: "buyOvenBtn",
    }
}

let structureCount = 0;

function capitalize(str) {
    return str.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

function showBuyStructureBtn() {
    structureStoreDiv.innerHTML = "";

    for (let i in structures) {
        if (totalCount < structures[i].minimum) continue;

        const btn = document.createElement("button");
        btn.textContent = `Buy ${capitalize(i)} (+${structures[i].bps} bps): $${structures[i].price.toFixed(0)}`;
        btn.onclick = () => {
            if(count >= structures[i].price){
                count -= structures[i].price;
                structures[i].count += 1;
                structures[i].price += structures[i].price * 0.25;
                autoCount += structures[i].bps;
                structureCount = structureCounter();
                console.log(structureCount);
                
                updateCount();
                displayStructures();

                if (structures.oven.count != 0) structureDiv.style.display = "block";
                btn.textContent = `Buy ${capitalize(i)} (+${structures[i].bps} bps): ${structures[i].price.toFixed(0)} breads`;
            }
        };

        structureStoreDiv.appendChild(btn);
    }
}

function saveStructures() {
    for (let i in structures) {
        localStorage.setItem(`${i}_price`, structures[i].price);
        localStorage.setItem(`${i}_count`, structures[i].count);
    }
}

function loadStructures() {
    for (let i in structures) {
        structures[i].price = parseFloat(localStorage.getItem(`${i}_price`)) || structures[i].price;
        structures[i].count = parseInt(localStorage.getItem(`${i}_count`)) || 0;
    }
}

function structureCounter() {
    let value = 0;
    for (let i in structures){
            value += structures[i].count;
    }
    return value;
}

function displayStructures() {
    structureDiv.innerHTML = "";
    for (let i in structures) {
        if (structures[i].count == 0) continue;
        const p = document.createElement("p");
        p.textContent = `${capitalize(i)}: ${structures[i].count} (+${structures[i].count * structures[i].bps} bps)`;
        structureDiv.appendChild(p);
    }
}
