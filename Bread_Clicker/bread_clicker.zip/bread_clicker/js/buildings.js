let structures = {
    oven: {
        price: 15,
        minimum: 0,
        count: 0,
        bps: 1,
        buttonId: "buyOvenBtn",
        showFn: () => {
            autoCount += 1;
        }
    }
}

const structureDiv = document.getElementById("structureStoreDiv");

function capitalize(str) {
    return str.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

function showBuyStructureBtn() {
    structureDiv.innerHTML = "";

    for (let i in structures) {
        if (totalCount < structures[i].minimum) continue;

        const btn = document.createElement("button");
        btn.textContent = `Buy ${capitalize(i)} (+${structures[i].bps} bps): $${structures[i].price.toFixed(0)}`;
        btn.onclick = () => {
            if(count >= structures[i].price){
                count -= structures[i].price;
                structures[i].showFn();
                structures[i].count += 1;
                structures[i].price += structures[i].price * 0.25;
                updateCount();
                btn.textContent = `Buy ${capitalize(i)} (+${structures[i].bps} bps): $${structures[i].price.toFixed(0)}`;
            }
        };

        structureDiv.appendChild(btn);
    }
}

function saveStructures() {
    for (let i in structures) {
        localStorage.setItem(`${i}_price`, structures[i].price);
        localStorage.setItem(`${i}_count`, structures[i].count);
    }
}

function loadStructures() {
    for (let i in structures) {
        structures[i].price = parseFloat(localStorage.getItem(`${i}_price`)) || structures[i].price;
        structures[i].count = parseInt(localStorage.getItem(`${i}_count`)) || 0;
    }
}